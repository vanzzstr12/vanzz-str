<?php
$shop_name = "VANZZ STORE";
$wa = "https://wa.me//6283124637175"; // GANTI NOMOR WA LU
$wa_link = "https://whatsapp.com/channel/0029VbC8AGHGU3BRyUmejs1Y".$wa;
$grup_link = "https://chat.whatsapp.com/KaYBUfeqGPK8MLujLEWHeG"; // GANTI LINK GRUP
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $shop_name ?> | Jual Beli Akun All Game Bergaransi</title>
<meta name="description" content="Platform jual beli akun Free Fire & Mobile Legends terpercaya. Proses cepat, aman, bergaransi 100%.">

<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Space+Grotesk:wght@300;400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root{
    --neon: #00f5ff;
    --neon2: #8b5cf6;
    --dark: #05050a;
    --glass: rgba(255,255,255,0.03);
    --card: rgba(15,15,30,0.6);
}

*{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
body{
    font-family:'Space Grotesk',sans-serif;
    background:var(--dark);
    color:#fff;
    overflow-x:hidden;
}

/* Background 2090 */
.bg{
    position:fixed;top:0;left:0;width:100%;height:100%;
    background: 
        radial-gradient(circle at 20% 20%, rgba(0,245,255,0.12) 0%, transparent 50%),
        radial-gradient(circle at 80% 80%, rgba(139,92,246,0.12) 0%, transparent 50%),
        var(--dark);
    z-index:-2;
}
.grid{
    position:fixed;top:0;left:0;width:100%;height:100%;
    background-image: 
        linear-gradient(rgba(0,245,255,0.05) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,245,255,0.05) 1px, transparent 1px);
    background-size:70px 70px;
    animation:grid 40s linear infinite;
    z-index:-1;opacity:0.4;
}
@keyframes grid{100%{transform:translate(70px,70px)}}
#particles{position:fixed;width:100%;height:100%;z-index:-1;opacity:0.5}

/* Navbar */
nav{
    position:fixed;top:20px;left:50%;transform:translateX(-50%);
    width:95%;max-width:1200px;
    background:var(--glass);backdrop-filter:blur(20px);
    border:1px solid rgba(0,245,255,0.15);
    border-radius:20px;padding:14px 24px;
    display:flex;justify-content:space-between;align-items:center;
    z-index:1000;animation:slideDown 0.6s ease;
}
@keyframes slideDown{from{transform:translate(-50%,-100px);opacity:0}}

.logo{display:flex;align-items:center;gap:12px}
.logo-icon{
    width:40px;height:40px;
    background:linear-gradient(135deg,var(--neon),var(--neon2));
    border-radius:12px;display:flex;align-items:center;justify-content:center;
    font:900 15px 'Orbitron';color:#000;box-shadow:0 0 20px rgba(0,245,255,0.4);
}
.logo-text h3{font:700 16px 'Orbitron';letter-spacing:1px}
.logo-text p{font-size:10px;color:#aaa;margin-top:2px}

.nav-menu{display:flex;gap:25px}
.nav-menu a{color:#ccc;text-decoration:none;font-size:13px;font-weight:600;transition:0.3s}
.nav-menu a:hover{color:var(--neon)}

.btn-wa{
    padding:10px 18px;background:linear-gradient(135deg,#25D366,#128C7E);
    border-radius:12px;color:#fff;font-weight:700;font-size:12px;
    text-decoration:none;display:flex;align-items:center;gap:6px;
    box-shadow:0 5px 15px rgba(37,211,102,0.4);transition:0.3s
}
.btn-wa:hover{transform:translateY(-2px);box-shadow:0 8px 25px rgba(37,211,102,0.6)}

.menu-toggle{display:none;font-size:22px;color:var(--neon);cursor:pointer}

/* Section */
section{padding:100px 20px;max-width:1200px;margin:0 auto}
.section-title{text-align:center;margin-bottom:50px}
.badge{
    display:inline-flex;align-items:center;gap:8px;
    padding:6px 16px;background:var(--glass);backdrop-filter:blur(10px);
    border:1px solid rgba(0,245,255,0.2);border-radius:50px;
    font-size:11px;color:var(--neon);margin-bottom:15px
}
.badge::before{content:'';width:6px;height:6px;background:var(--neon);border-radius:50%;box-shadow:0 0 8px var(--neon);animation:pulse 2s infinite}
@keyframes pulse{50%{opacity:0.3}}

h2{font:900 36px 'Orbitron';margin-bottom:12px}
h2 span{background:linear-gradient(135deg,var(--neon),var(--neon2));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.section-desc{color:#aaa;font-size:15px;max-width:600px;margin:0 auto;line-height:1.7}

/* Hero */
#hero{min-height:100vh;display:flex;align-items:center;justify-content:center;text-align:center;padding-top:140px}
.hero h1{font:900 clamp(28px,5vw,56px) 'Orbitron';line-height:1.2;margin-bottom:20px}
.hero h1 span{background:linear-gradient(135deg,var(--neon),var(--neon2));-webkit-background-clip:text;-webkit-text-fill-color:transparent;filter:drop-shadow(0 0 30px rgba(0,245,255,0.4))}
.hero p{color:#aaa;font-size:16px;max-width:650px;margin:0 auto 35px;line-height:1.7}

.btn-group{display:flex;flex-wrap:wrap;gap:15px;justify-content:center;margin-bottom:50px}
.btn{
    padding:15px 30px;border-radius:14px;font-weight:700;font-size:14px;
    text-decoration:none;display:flex;align-items:center;gap:8px;
    transition:0.4s;font-family:'Space Grotesk';position:relative;overflow:hidden
}
.btn-primary{background:linear-gradient(135deg,var(--neon),var(--neon2));color:#000;box-shadow:0 10px 30px rgba(0,245,255,0.4)}
.btn-primary:hover{transform:translateY(-4px);box-shadow:0 15px 40px rgba(0,245,255,0.7)}
.btn-outline{background:var(--glass);backdrop-filter:blur(10px);border:1.5px solid rgba(0,245,255,0.3);color:#fff}
.btn-outline:hover{border-color:var(--neon);box-shadow:0 0 25px rgba(0,245,255,0.4);transform:translateY(-4px)}

.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;max-width:900px;margin:0 auto}
.stat-card{
    background:var(--card);backdrop-filter:blur(15px);
    border:1px solid rgba(0,245,255,0.1);border-radius:18px;padding:25px;
    text-align:center;transition:0.3s
}
.stat-card:hover{border-color:var(--neon);transform:translateY(-5px);box-shadow:0 10px 30px rgba(0,245,255,0.2)}
.stat-num{font:900 32px 'Orbitron';background:linear-gradient(135deg,var(--neon),var(--neon2));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.stat-label{font-size:12px;color:#888;margin-top:5px;letter-spacing:1px}

/* Stok */
.card-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:25px}
.card{
    background:var(--card);backdrop-filter:blur(15px);
    border:1px solid rgba(0,245,255,0.1);border-radius:20px;padding:25px;
    transition:0.4s;position:relative;overflow:hidden
}
.card::before{
    content:'';position:absolute;top:0;left:-100%;width:100%;height:100%;
    background:linear-gradient(90deg,transparent,rgba(0,245,255,0.1),transparent);
    transition:0.6s
}
.card:hover::before{left:100%}
.card:hover{border-color:var(--neon);transform:translateY(-8px);box-shadow:0 15px 40px rgba(0,245,255,0.25)}

.card-badge{
    position:absolute;top:15px;right:15px;
    padding:5px 12px;background:linear-gradient(135deg,#ff9500,#ff3b00);
    border-radius:8px;font-size:10px;font-weight:700;color:#000
}

.game-icon{font-size:40px;color:var(--neon);margin-bottom:15px}
.card h3{font:700 18px 'Orbitron';margin-bottom:8px}
.card p{color:#aaa;font-size:13px;margin-bottom:15px;line-height:1.6}
.price{font:900 22px 'Orbitron';color:var(--neon);margin-bottom:15px}
.btn-card{
    width:100%;padding:12px;background:linear-gradient(135deg,var(--neon),var(--neon2));
    border:none;border-radius:12px;color:#000;font-weight:700;font-size:13px;
    cursor:pointer;text-decoration:none;display:block;text-align:center;transition:0.3s
}
.btn-card:hover{box-shadow:0 8px 20px rgba(0,245,255,0.5)}

/* Cara Beli */
.steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:25px}
.step{
    background:var(--card);backdrop-filter:blur(15px);
    border:1px solid rgba(0,245,255,0.1);border-radius:20px;padding:30px 20px;
    text-align:center;position:relative
}
.step-num{
    width:50px;height:50px;margin:0 auto 15px;
    background:linear-gradient(135deg,var(--neon),var(--neon2));
    border-radius:50%;display:flex;align-items:center;justify-content:center;
    font:900 20px 'Orbitron';color:#000;box-shadow:0 0 20px rgba(0,245,255,0.4)
}
.step h4{font:700 16px 'Orbitron';margin-bottom:8px}
.step p{color:#aaa;font-size:13px;line-height:1.6}

/* Testimoni */
.testi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:25px}
.testi{
    background:var(--card);backdrop-filter:blur(15px);
    border:1px solid rgba(0,245,255,0.1);border-radius:20px;padding:25px
}
.testi-top{display:flex;align-items:center;gap:12px;margin-bottom:15px}
.avatar{
    width:45px;height:45px;border-radius:50%;
    background:linear-gradient(135deg,var(--neon),var(--neon2));
    display:flex;align-items:center;justify-content:center;font-weight:700;color:#000
}
.stars{color:#ffc107;font-size:12px}
.testi p{color:#ccc;font-size:14px;line-height:1.7;font-style:italic}

/* FAQ */
.faq-item{
    background:var(--card);backdrop-filter:blur(15px);
    border:1px solid rgba(0,245,255,0.1);border-radius:15px;margin-bottom:12px;
    overflow:hidden
}
.faq-q{
    padding:18px 20px;cursor:pointer;display:flex;justify-content:space-between;
    align-items:center;font-weight:600;font-size:14px
}
.faq-q:hover{color:var(--neon)}
.faq-a{max-height:0;overflow:hidden;transition:0.4s}
.faq-a p{padding:0 20px 18px;color:#aaa;font-size:13px;line-height:1.7}
.faq-item.active .faq-a{max-height:200px}

/* Footer */
footer{
    background:var(--card);backdrop-filter:blur(15px);
    border-top:1px solid rgba(0,245,255,0.1);padding:50px 20px 20px
}
.footer-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:40px;max-width:1200px;margin:0 auto 40px}
footer h4{font:700 16px 'Orbitron';margin-bottom:15px;color:var(--neon)}
footer p,footer a{color:#aaa;font-size:13px;line-height:1.7;text-decoration:none;display:block;margin-bottom:8px;transition:0.3s}
footer a:hover{color:var(--neon)}
.social{display:flex;gap:12px;margin-top:15px}
.social a{
    width:38px;height:38px;background:var(--glass);border:1px solid rgba(0,245,255,0.2);
    border-radius:10px;display:flex;align-items:center;justify-content:center;color:var(--neon);transition:0.3s
}
.social a:hover{background:var(--neon);color:#000}
.copy{border-top:1px solid rgba(0,245,255,0.1);padding-top:20px;text-align:center;color:#666;font-size:12px}

/* Mobile */
@media(max-width:900px){
    .nav-menu{display:none;position:absolute;top:70px;left:0;width:100%;flex-direction:column;background:var(--dark);border:1px solid rgba(0,245,255,0.2);border-radius:15px;padding:20px}
    .nav-menu.active{display:flex}
    .menu-toggle{display:block}
    .stats{grid-template-columns:repeat(2,1fr)}
    h2{font-size:28px}
</style>
</head>
<body>

<div class="bg"></div>
<div class="grid"></div>
<div id="particles"></div>

<nav>
    <div class="logo">
        <div class="logo-icon">VS</div>
        <div class="logo-text">
            <h3><?= $shop_name ?></h3>
            <p>Akun Game Bergaransi</p>
        </div>
    </div>
    <div class="nav-menu" id="menu">
        <a href="#hero">Home</a>
        <a href="#stok">Stok Akun</a>
        <a href="#cara">Cara Beli</a>
        <a href="#testi">Testimoni</a>
        <a href="#faq">FAQ</a>
    </div>
    <a href="<?= $wa_link ?>" target="_blank" class="btn-wa"><i class="fab fa-whatsapp"></i> Chat</a>
    <div class="menu-toggle" onclick="document.getElementById('menu').classList.toggle('active')"><i class="fas fa-bars"></i></div>
</nav>

<section id="hero">
    <div>
        <div class="badge">PLATFORM #1 JUAL BELI AKUN GAME</div>
        <h1>JUAL BELI AKUN<br><span>ALL GAME</span><br>TERPERCAYA 2090</h1>
        <p>Temukan akun impianmu atau jual akunmu dengan harga terbaik. Proses instan 3 menit, sistem aman, bergaransi 100%. Dipercaya 100+ gamer Indonesia.</p>
        <div class="btn-group">
            <a href="#stok" class="btn btn-primary"><i class="fas fa-gamepad"></i> Lihat Stok Akun</a>
            <a href="<?= $grup_link ?>" target="_blank" class="btn btn-outline"><i class="fas fa-users"></i> Grup Komunitas</a>
        </div>
        <div class="stats">
            <div class="stat-card"><div class="stat-num">100+</div><div class="stat-label">Akun Terjual</div></div>
            <div class="stat-card"><div class="stat-num">3 Thn+</div><div class="stat-label">Pengalaman</div></div>
            <div class="stat-card"><div class="stat-num">99%</div><div class="stat-label">Kepuasan</div></div>
            <div class="stat-card"><div class="stat-num">24/7</div><div class="stat-label">Support</div></div>
        </div>
    </div>
</section>

<section id="cara">
    <div class="section-title">
        <div class="badge">MUDAH BANGET</div>
        <h2>CARA <span>BELI</span> AKUN</h2>
        <p class="section-desc">Cukup 4 langkah, akun langsung jadi milikmu dalam 3 menit</p>
    </div>
    <div class="steps">
        <div class="step"><div class="step-num">1</div><h4>Pilih Akun</h4><p>Pilih akun sesuai budget & keinginan kamu di katalog</p></div>
        <div class="step"><div class="step-num">2</div><h4>Chat Admin</h4><p>Klik tombol beli, otomatis chat ke WA admin</p></div>
        <div class="step"><div class="step-num">3</div><h4>Bayar Aman</h4><p>Transfer via bank, e-wallet, atau qris. Bergaransi</p></div>
        <div class="step"><div class="step-num">4</div><h4>Akun Dikirim</h4><p>Data login + tutorial ganti email langsung dikirim</p></div>
    </div>
</section>

<section id="testi">
    <div class="section-title">
        <div class="badge">BUKTI NYATA</div>
        <h2>TESTIMONI <span>PEMBELI</span></h2>
        <p class="section-desc">Ribuan review positif dari customer yang udah transaksi</p>
    </div>
    <div class="testi-grid">
        <div class="testi">
            <div class="testi-top">
                <div class="avatar">R</div>
                <div><h4>Rizky Gamer</h4><div class="stars">★★★</div></div>
            </div>
            <p>"Pelayanan cepat banget, 5 menit langsung dikirim akunnya. Amanah 100%, bakal langganan terus!"</p>
        </div>
        <div class="testi">
            <div class="testi-top">
                <div class="avatar">A</div>
                <div><h4>Andi Pro</h4><div class="stars">★★★</div></div>
            </div>
            <p>"Akun sesuai deskripsi, skin semua ada. Admin ramah dan ngajarin cara ganti email. Mantap!"</p>
        </div>
        <div class="testi">
            <div class="testi-top">
                <div class="avatar">S</div>
                <div><h4>Sarah ML</h4><div class="stars">★★★</div></div>
            </div>
            <p>"Udah 3x beli disini, gak pernah zonk. Harga miring tapi kualitas sultan. Rekomendasi!"</p>
        </div>
    </div>
</section>

<section id="faq">
    <div class="section-title">
        <div class="badge">TANYA JAWAB</div>
        <h2>FAQ <span>UM</span></h2>
    </div>
    <div style="max-width:800px;margin:0 auto">
        <div class="faq-item">
            <div class="faq-q">Apakah akun bergaransi? <i class="fas fa-chevron-down"></i></div>
            <div class="faq-a"><p>100% bergaransi. Kalau ada kendala login dalam 7x24 jam, kami ganti akun baru atau refund 100%.</p></div>
        </div>
        <div class="faq-item">
            <div class="faq-q">Proses pengiriman berapa lama? <i class="fas fa-chevron-down"></i></div>
            <div class="faq-a"><p>Instans! Setelah pembayaran dikonfirmasi, data login dikirim via WA dalam 3-5 menit.</p></div>
        </div>
        <div class="faq-item">
            <div class="faq-q">Bisa COD atau rekber? <i class="fas fa-chevron-down"></i></div>
            <div class="faq-a"><p>Bisa via rekber grup Facebook atau Tokopedia. COD area Jabodetabek only.</p></div>
        </div>
    </div>
</section>

<footer>
    <div class="footer-grid">
        <div>
            <div class="logo" style="margin-bottom:15px">
                <div class="logo-icon">NX</div>
                <div class="logo-text"><h3><?= $shop_name ?></h3></div>
            </div>
            <p>Platform jual beli akun game terpercaya sejak 2023. Aman, cepat, bergaransi 100%.</p>
            <div class="social">
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-tiktok"></i></a>
                <a href="<?= $wa_link ?>" target="_blank"><i class="fab fa-whatsapp"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
        <div>
            <h4>Menu</h4>
            <a href="#hero">Home</a>
            <a href="#stok">Stok Akun</a>
            <a href="#cara">Cara Beli</a>
            <a href="#testi">Testimoni</a>
        </div>
        <div>
            <h4>Kontak</h4>
            <a href="<?= $wa_link ?>" target="_blank"><i class="fab fa-whatsapp mr-2"></i>WhatsApp Admin</a>
            <a href="mailto:admin@nexus2090.com"><i class="fas fa-envelope mr-2"></i>Email Support</a>
            <p><i class="fas fa-clock mr-2"></i>Online 24/7</p>
        </div>
    </div>
    <div class="copy">© 2026 <?= $shop_name ?>. All Rights Reserved. | Design By Vanzz Team</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script>
particlesJS('particles',{
    "particles":{
        "number":{"value":120,"density":{"enable":true,"value_area":800}},
        "color":{"value":["#00f5ff","#8b5cf6"]},
        "shape":{"type":"circle"},
        "opacity":{"value":0.5,"random":true},
        "size":{"value":3,"random":true},
        "line_linked":{"enable":true,"distance":140,"color":"#00f5ff","opacity":0.25,"width":1},
        "move":{"enable":true,"speed":2,"direction":"none","random":true,"out_mode":"out"}
    }
});

// FAQ Toggle
document.querySelectorAll('.faq-q').forEach(q=>{
    q.onclick=()=>q.parentElement.classList.toggle('active')
});
</script>

</body>
</html>